# Related Tutorials

* [Defining Hibernate Association Mappings](https://howtodoinjava.com/hibernate/how-to-define-association-mappings-between-hibernate-entities/)
* [Hibernate One to One Mapping](https://howtodoinjava.com/hibernate/hibernate-one-to-one-mapping/)
* [Hibernate One to Many Mapping](https://howtodoinjava.com/hibernate/hibernate-one-to-many-mapping/)
* [Hibernate Many to Many Mapping](https://howtodoinjava.com/hibernate/hibernate-many-to-many-mapping/)
* [Hibernate Mapping Date, Time and Timestamp](https://howtodoinjava.com/hibernate/date-time-mappings/)